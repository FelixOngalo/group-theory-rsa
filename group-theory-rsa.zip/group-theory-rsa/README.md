# Group Theory and RSA

**Question:** *(fill in)* Why does RSA decryption always recover the message, and what is the only thing standing between an attacker and the private key?

**Key findings:** *(fill in after running: zero violations of Lagrange/Euler/Fermat, RSA round-trips including non-coprime messages, factoring-time growth)*

**Tools:** R (base only), Quarto report with full proofs in LaTeX

## Why this project exists

Third in the pure-math series for an MSc Pure Mathematics portfolio, this time from abstract algebra and number theory. Every theorem is proved in full, then verified exhaustively on small cases by from-scratch code.

## Reproduce

1. `install.packages("tidyverse")` (only needed to render the report)
2. Run `R/01_verify_theory.R`
3. Render `reports/report.qmd`

## Theorems covered

| Result | Role |
|---|---|
| Bézout / extended Euclid | Modular inverses exist exactly for units |
| Lagrange's theorem | The order of every element divides the group order |
| Euler / Fermat | a^phi(n) = 1 (mod n); a^(p-1) = 1 (mod p) |
| RSA correctness | m^(ed) = m (mod n) for all m, via Fermat and CRT |

## Project structure

```
R/number_theory_functions.R  gcd, extended Euclid, modular inverse and power,
                              unit group, element order, RSA keygen/encrypt/decrypt,
                              trial-division attack
R/01_verify_theory.R         exhaustive checks and the factoring-time experiment
reports/report.qmd           proofs, verification tables, security discussion
```

## Limitations

- Arithmetic limited to n < 9e7 (exact double precision); real RSA needs big integers and padding.
- Textbook RSA is not secure for real use.
- *(add your own)*
