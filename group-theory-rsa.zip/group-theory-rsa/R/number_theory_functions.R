# Modular arithmetic and group-theory tools, written from scratch.
#
# SCALE NOTE: R doubles are exact for integers below 2^53 (~9.0e15).
# A modular product a*b with a, b < n is exact when n < ~9.4e7, so all
# modular-arithmetic functions here assume n < 9e7. That is plenty to
# verify the theorems exhaustively; real RSA uses 2048-bit numbers and
# needs arbitrary-precision arithmetic (e.g. the `gmp` package).

#' Greatest common divisor by the Euclidean algorithm.
gcd <- function(a, b) {
  while (b != 0) { t <- b; b <- a %% b; a <- t }
  abs(a)
}

#' Extended Euclid: returns list(g, x, y) with a*x + b*y = g = gcd(a, b).
#' Bezout's identity is what makes modular inverses exist, and this
#' function constructs the coefficients.
gcd_ext <- function(a, b) {
  old_r <- a; r <- b
  old_x <- 1; x <- 0
  old_y <- 0; y <- 1
  while (r != 0) {
    q <- old_r %/% r
    tmp <- old_r - q * r; old_r <- r; r <- tmp
    tmp <- old_x - q * x; old_x <- x; x <- tmp
    tmp <- old_y - q * y; old_y <- y; y <- tmp
  }
  list(g = old_r, x = old_x, y = old_y)
}

#' Modular inverse of a mod n: the b with a*b = 1 (mod n). Exists iff
#' gcd(a, n) = 1, which is exactly the condition for a to be in the
#' group of units.
mod_inverse <- function(a, n) {
  e <- gcd_ext(a %% n, n)
  if (e$g != 1) stop("no inverse: gcd(a, n) != 1")
  e$x %% n
}

#' Fast modular exponentiation by repeated squaring: O(log e) steps
#' instead of e multiplications.
mod_pow <- function(base, exp, n) {
  result <- 1
  base <- base %% n
  while (exp > 0) {
    if (exp %% 2 == 1) result <- (result * base) %% n
    base <- (base * base) %% n
    exp <- exp %/% 2
  }
  result
}

#' Euler's totient: how many integers in 1..n are coprime to n.
euler_phi <- function(n) sum(vapply(seq_len(n), function(k) gcd(k, n) == 1, logical(1)))

#' The group of units (Z/nZ)^*: all residues coprime to n. It is a
#' group under multiplication mod n (closed, associative, identity 1,
#' inverses exist) with exactly phi(n) elements.
unit_group <- function(n) Filter(function(k) gcd(k, n) == 1, seq_len(n - 1))   # assumes n >= 2

#' Multiplicative order of a in (Z/nZ)^*: smallest k >= 1 with a^k = 1.
element_order <- function(a, n) {
  k <- 1; x <- a %% n
  while (x != 1) { x <- (x * a) %% n; k <- k + 1 }
  k
}

#' Textbook RSA key generation from two distinct primes p, q and a
#' public exponent e coprime to phi(n) = (p-1)(q-1).
rsa_keygen <- function(p, q, e = 65537) {
  n <- p * q
  phi <- (p - 1) * (q - 1)
  if (gcd(e, phi) != 1) stop("e must be coprime to (p-1)(q-1)")
  d <- mod_inverse(e, phi)
  list(n = n, e = e, d = d, p = p, q = q, phi = phi)
}

rsa_encrypt <- function(m, key) mod_pow(m, key$e, key$n)
rsa_decrypt <- function(c, key) mod_pow(c, key$d, key$n)

#' Attack: recover the smallest prime factor of n by trial division.
#' Costs ~sqrt(n) operations, which is why RSA security rests on n
#' being too large to factor, not on any secrecy in the algorithm.
trial_division_factor <- function(n) {
  candidates <- 2:floor(sqrt(n))
  candidates[which(n %% candidates == 0)[1]]
}
