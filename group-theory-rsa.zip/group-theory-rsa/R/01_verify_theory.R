source("R/number_theory_functions.R")
set.seed(42)

cat("=== 1. Lagrange's theorem: element order divides |group| ===\n")
# Exhaustive check over several moduli, prime and composite.
moduli <- c(7, 11, 15, 21, 35, 97, 100, 221, 1001)
lagrange <- do.call(rbind, lapply(moduli, function(n) {
  units <- unit_group(n)
  phi <- length(units)
  orders <- vapply(units, element_order, numeric(1), n = n)
  data.frame(n = n, group_order = phi, elements_checked = length(units),
             violations = sum(phi %% orders != 0),
             max_element_order = max(orders),
             is_cyclic = max(orders) == phi)
}))
print(lagrange)

cat("\n=== 2. Euler's theorem: a^phi(n) = 1 for every unit a ===\n")
euler_violations <- sum(vapply(moduli, function(n) {
  units <- unit_group(n); phi <- length(units)
  sum(vapply(units, function(a) mod_pow(a, phi, n) != 1, logical(1)))
}, numeric(1)))
cat("Violations across all moduli:", euler_violations, "\n")

cat("\n=== 3. Fermat's little theorem for primes (a^(p-1) = 1) ===\n")
primes <- c(5, 13, 101, 1009, 10007)
fermat_ok <- vapply(primes, function(p) {
  a <- sample(1:(p - 1), min(500, p - 1))
  all(vapply(a, function(x) mod_pow(x, p - 1, p) == 1, logical(1)))
}, logical(1))
print(data.frame(p = primes, holds_for_sampled_a = fermat_ok))

cat("\n=== 4. RSA correctness: decrypt(encrypt(m)) = m ===\n")
key <- rsa_keygen(p = 1009, q = 1013, e = 65537)
cat("n =", key$n, " e =", key$e, " d =", key$d, "\n")
# Random messages, plus messages that are multiples of p or q (NOT
# coprime to n) -- the proof covers these too, via the CRT argument.
msgs <- unique(c(sample(0:(key$n - 1), 20000),
                 key$p * (1:50), key$q * (1:50), 0, 1, key$n - 1))
roundtrip_ok <- vapply(msgs, function(m) rsa_decrypt(rsa_encrypt(m, key), key) == m, logical(1))
cat("Messages tested:", length(msgs), " failures:", sum(!roundtrip_ok), "\n")
non_coprime <- msgs[vapply(msgs, function(m) gcd(m, key$n) != 1, logical(1))]
cat("  of which not coprime to n:", length(non_coprime),
    " failures among them:", sum(!roundtrip_ok[msgs %in% non_coprime]), "\n")

cat("\n=== 5. Why key size matters: trial-division factoring time ===\n")
pairs <- list(c(101, 103), c(1009, 1013), c(10007, 10009), c(100003, 100019), c(1000003, 1000033))
factoring <- do.call(rbind, lapply(pairs, function(pq) {
  n <- pq[1] * pq[2]
  t <- system.time(f <- trial_division_factor(n))[["elapsed"]]
  data.frame(n = n, bits = ceiling(log2(n)), factor_found = f, seconds = t)
}))
print(factoring)

saveRDS(list(lagrange = lagrange, euler_violations = euler_violations,
             fermat = data.frame(p = primes, ok = fermat_ok), key = key,
             rsa_tested = length(msgs), rsa_failures = sum(!roundtrip_ok),
             non_coprime_tested = length(non_coprime),
             non_coprime_failures = sum(!roundtrip_ok[msgs %in% non_coprime]),
             factoring = factoring),
        "data/clean/verification_results.rds")
